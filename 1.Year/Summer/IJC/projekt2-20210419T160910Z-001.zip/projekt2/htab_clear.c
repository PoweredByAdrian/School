#include <stdlib.h>
#include "htab.h"
#include "htab_struct.h"

void htab_clear(htab_t * t)
{
    for (int i=0;i<t->arr_size;i++)
    {
        if (t->items[i] != NULL)
        {
            struct htab_item *temp = t->items[i];
            struct htab_item *temp2;
            while (temp != NULL)
            {
                temp2 = temp->next;

                htab_pair_t *data = temp->data;
                free(data);
                free(temp);
                temp = temp2;
            }
        }

        //free(t->items[i]);
    }
}