#include <stdlib.h>
#include <stdio.h>
#include "htab.h"
#include "htab_struct.h"


htab_t *htab_move(size_t n, htab_t *from)
{
    htab_t *tab = htab_init(n);

    for (int i=0;i<from->arr_size;i++)
    {
        tab->items[i] = from->items[i];
    }

    htab_clear(from);

    return tab;
}