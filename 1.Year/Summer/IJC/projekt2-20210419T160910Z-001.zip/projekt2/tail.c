#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MAX_LENGTH 511


FILE *open_file(char *filename)
{
    FILE *fp;

    fp = fopen(filename, "r");
    if (fp == NULL)
    {
        fprintf(stderr, "error opening file\n");
    }

    return fp;
}

int line_counter(FILE *file)
{
    int count = 0;
    char line[MAX_LENGTH];

    while (fgets(line, MAX_LENGTH, file))
    {
        count++;
    }

    return count;
}


int main(int argc, char *argv[])
{
    int n = 10;
    int count = 0;
    char buffer[MAX_LENGTH];
    FILE *file = NULL;
    int lines_count = 0;

    if (argc > 1 && argc != 3)
    {
        file = open_file(argv[argc - 1]);
    }

    for (int i=0;i<argc;i++)
    {
        if (strncmp(argv[i], "-n", 3) == 0)
        {
            if (argv[i + 1] == NULL)
            {
                fprintf(stderr, "nespecifikovany parameter 'n'");
                break;
            }
            n = (strtol(argv[i + 1], NULL, 10));
        }
    }

    if (file == NULL)
    {
        lines_count = line_counter(stdin);
        rewind(stdin);

        while (fgets(buffer, MAX_LENGTH, stdin))
        {
            if (count >= (lines_count - n))
            {
                printf("%s", buffer);
            }

            count++;
        }
        
    }

    else
    {
        lines_count = line_counter(file);
        file = open_file(argv[argc - 1]);

        while (fgets(buffer, MAX_LENGTH, file))
        {
            if (strlen(buffer) + 1 == MAX_LENGTH)
            {                                   
                count++;
                continue;
            }

            if (count >= (lines_count - n))
            {
                printf("%s", buffer);
            }

            count++;
        }

    }

    return 0;
}