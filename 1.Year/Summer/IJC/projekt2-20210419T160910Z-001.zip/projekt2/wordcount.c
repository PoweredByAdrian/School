#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include "htab.h"
#include "htab_struct.h"
#include "hash_function.c"
#include "htab_bucket_count.c"
#include "htab_move.c"
#include "htab_clear.c"
#include "htab_find.c"
#include "htab_lookup_add.c"
#include "htab_erase.c"
#include "htab_for_each.c"
#include "htab_free.c"
#include "htab_init.c"


int string(char *x, FILE *f)
{
    int i = 0;
    int c;

    while ((c = fgetc(f)) != EOF)
    {
        
        if (isspace(c))
        {
            if (i == 0)
                continue;
            x[i] = '\0';
            return c;
        }
        else
        {
        x[i]=c;
        i++;
        }  
    }
    if (c == EOF)
        return EOF;
    //ZISTIT CI FUNGUJE AJ PRE POSLEDNE SLOVO!    
    
}

void print_table(htab_pair_t *data)
{
    printf("%s : %d\n", data->key, data->value);
}


int main(int argc, char const *argv[])
{
    char x[128];
    htab_key_t word;
    int i=0;

    htab_t *table = htab_init(500);
    htab_pair_t *item;
    
    while ((string(x, stdin))!=EOF)
    {
            //ZISKAJ UKAZATEL NA SLOVO
        //strcpy(word, x);

        item = htab_lookup_add(table, x);

        //SKONTROLUJ CI JE UKAZATEL OK
        if (htab_find(table, word) == NULL)
        {
        }
          
        //ZVACSI POCET VYSKYTOV SLOV
        item->value += 1;  
    }



    //PRECHADZAJ POLE
        //void htab_for_each(const htab_t * table, void (*f)(htab_pair_t *data));
        //VYPIS PRVKOV NA STDOUT
        //printf("%s\t%d\n",slovo, pocet)



    //UVOLNENIE TABULKY

    //void htab_free(htab_t * t);

    htab_for_each(table, print_table);
    htab_free(table);

    return 0;
}