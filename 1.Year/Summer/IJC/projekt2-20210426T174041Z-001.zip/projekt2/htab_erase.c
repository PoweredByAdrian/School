#include <stdbool.h>
#include <string.h>
#include "htab.h"
#include "htab_struct.h"

bool htab_erase(htab_t *t, htab_key_t key)
{
    size_t index = htab_hash_function(key) % t->arr_size;
    struct htab_item *prev = t->items[index];
    struct htab_item *curr = t->items[index];
    bool tofree = false;

    while(curr!=NULL)
    {
        if (strcmp(curr->data->key, key) == 0)
        {
            if (tofree)
            {
                prev->next = curr->next;
                free(curr->data);
                free(curr);
                curr = NULL;
                return true;
            }
                
            t->items[index] = NULL;
            return true;
        }
        
        prev = curr;
        curr = curr->next;
        tofree = true;
    }

    return false;
}