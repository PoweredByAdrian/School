#include <stdio.h>
#include <string.h>
#include "htab.h"
#include "htab_struct.h"


htab_pair_t *htab_find(htab_t *t, htab_key_t key)
{
    size_t index = htab_hash_function(key) % t->arr_size;
    
    struct htab_item *temp = t->items[index];

    while(temp!=NULL)
    {
        if (strcmp(temp->data->key, key) == 0)
        {
            return temp->data;
        }
        
        temp = temp->next;
    }

    return NULL;
}