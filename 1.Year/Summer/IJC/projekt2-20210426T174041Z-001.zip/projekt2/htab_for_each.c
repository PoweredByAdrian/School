#include "htab.h"
#include "htab_struct.h"

void htab_for_each(const htab_t * t, void (*f)(htab_pair_t *data))
{
    for (int i=0;i<t->arr_size;i++)
    {
        if (t->items[i] != NULL)
        {
            struct htab_item *temp = t->items[i];
            while (temp != NULL)
            {
                htab_pair_t *data = temp->data;
                f(data);

                temp = temp->next;

            }
        }
    }
}