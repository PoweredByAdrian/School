#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "htab.h"
#include "htab_struct.h"


htab_pair_t *htab_lookup_add(htab_t *t, htab_key_t key)
{
    htab_pair_t *item = NULL;
    
    item = htab_find(t, key);
    if (item != NULL)
    {
        return item;
    }
    else
    {
        size_t index = htab_hash_function(key) % t->arr_size;

        if (t->items[index] == NULL)
        {
            t->items[index] = malloc(sizeof(struct htab_item));
            if (t->items[index] == NULL) return NULL;

            t->items[index]->data = malloc(sizeof(htab_pair_t));
            if (t->items[index]->data == NULL) return NULL;

            t->items[index]->data->key = malloc(sizeof(key));
            if (t->items[index]->data->key == NULL) return NULL;

            strncpy((char*) t->items[index]->data->key, key, strlen(key));
            t->items[index]->data->value = 0;
            t->size++;
            item = t->items[index]->data;
        }
        else
        {
            struct htab_item *temp = t->items[index];
            struct htab_item *temp2;

            while(temp->next!=NULL)
            {   
                temp = temp->next;
            }

            temp2 = malloc(sizeof(struct htab_item));
            if (temp2 == NULL) return NULL;

            temp2->data = malloc(sizeof(htab_pair_t));
            if (temp2->data == NULL) return NULL;

            temp2->data->key = malloc(sizeof(key));
            if (temp2->data->key == NULL) return NULL;

            strncpy((char*) temp2->data->key, key, strlen(key));
            temp2->data->value = 0;
            t->size++;
            temp->next = temp2;
            item = temp2->data;
        }

        return item;
    }
}