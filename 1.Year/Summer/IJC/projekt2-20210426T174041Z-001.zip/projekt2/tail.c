#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MAX_LENGTH 511
#define DEFAULT_LINE_COUNT 10


FILE *open_file(char *filename)
{
    FILE *fp;

    fp = fopen(filename, "r");
    if (fp == NULL)
    {
        fprintf(stderr, "error opening file\n");
    }

    return fp;
}

int main(int argc, char *argv[])
{
    int n = DEFAULT_LINE_COUNT;
    int count = 0;
    char buffer[MAX_LENGTH];
    FILE *file = NULL;
    int line_count = 0;
    bool file_opened = false;

    if (argc > 1 && argc != 3)
    {
        file = open_file(argv[argc - 1]);
        file_opened = true;
    }

    for (int i=0;i<argc;i++)
    {
        if (strncmp(argv[i], "-n", 3) == 0)
        {
            if (argv[i + 1] == NULL)
            {
                fprintf(stderr, "nespecifikovany parameter 'n'");
                break;
            }
            n = (strtol(argv[i + 1], NULL, 10));
        }
    }

    
    char* text = malloc(MAX_LENGTH);
    int offset = 0;
    bool first_output = true;
    char* line = NULL;
    FILE *file_temp;
    if (!file_opened)
        file_temp = stdin;
    else
        file_temp = file;

    while ((line = fgets(buffer, MAX_LENGTH, file_temp)) != NULL)
    {
        if(buffer[MAX_LENGTH] == '\0')
        {
            line_count++;
            memcpy(text + offset, buffer, strlen(buffer));
            offset += strlen(buffer);
            text = realloc(text, offset + MAX_LENGTH);
        }
        else if (buffer[MAX_LENGTH] != '\0' && first_output)
        {
            fprintf(stderr, "Prekroceny limit maximalneho poctu znakov na riadku \n");
            text = realloc(text, offset + MAX_LENGTH + 2);
            text[offset + MAX_LENGTH + 1] = '\n';
            text[offset + MAX_LENGTH + 2] = '\0';

            memcpy(text + offset, buffer, strlen(buffer));

            offset = offset + MAX_LENGTH + 2;
            first_output = false;
            line_count++;
        }
        else if (buffer[MAX_LENGTH] != '\0')
        {
            text = realloc(text, offset + MAX_LENGTH + 2);
            text[offset + MAX_LENGTH + 1] = '\n';
            text[offset + MAX_LENGTH + 2] = '\0';

            memcpy(text + offset, buffer, strlen(buffer));

            offset = offset + MAX_LENGTH + 2;
            line_count++;
        }
    }

    char* line_text = NULL;
    int offset2 = 0;
    char new_line[] = "\n";
    int text_line_count = 0;

    while((line_text = strstr(text + offset2, new_line)) != NULL)
    {
        int line_position = line_text - text;

        text_line_count++;

        if(line_count - text_line_count <= n)
        {
            char temp_buffer[MAX_LENGTH] = {0};

            char* temp = NULL;

            if((temp = strstr(text + offset2, new_line)) != NULL)
            {
                int temp_position  = temp - text;

                strncpy(temp_buffer, text + offset2, temp_position - offset2);
                temp_buffer[temp_position - offset2 + 1] = '\0';
                printf("%s\n", temp_buffer);
            }
    
        }

        offset2 = line_position  + 1; // preskocenie za \n
    }

    free(text);
    return 0;

}