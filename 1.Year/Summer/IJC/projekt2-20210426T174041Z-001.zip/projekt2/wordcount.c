#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "htab.h"
#include "htab_struct.h"

#define MAX_HTAB_SIZE 60000 // maximalny pocet slov v tabulke
#define MAX_WORD_LENGTH 128 // maximalna dlzka slova

void print_item(htab_pair_t *data)
{
    printf("%s\t%d\n", data->key, data->value);
}


int main()
{

    htab_t *table = htab_init(MAX_HTAB_SIZE); // vytvori tabulku
    char buffer[MAX_WORD_LENGTH];
    htab_pair_t *item;
    
    while (fscanf(stdin, "%s", buffer) != EOF) // nacita slova z stdin
    {   
        item = htab_lookup_add(table, buffer); // prida slovo do hashovacej tabulky
        item->value += 1; // inkrementuje pocet vyskytov slova

    }

    htab_for_each(table, print_item); // vyprintuje kazdy item tabulky
    htab_free(table); // uvolni alokovanu tabulku

    return 0;
}