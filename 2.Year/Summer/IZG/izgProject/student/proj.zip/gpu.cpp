/*!
 * @file
 * @brief This file contains implementation of gpu
 *
 * @author Tomáš Milet, imilet@fit.vutbr.cz
 */

#include <bit>
#include <array>
#include <iostream>
#include <algorithm>
#include <student/gpu.hpp>

using Triangle = std::array<OutVertex, 3>;

void  VertexAssembly(GPUContext& ctx, InVertex& in)
{
    for (uint32_t i = 0; i < maxAttributes; i++)
    {
        const auto& att = ctx.vao.vertexAttrib[i];
        auto index = att.offset + in.gl_VertexID * att.stride;
        const auto& buffer = (uint8_t*)(att.bufferData) + index;
        switch (att.type)
        {
        case AttributeType::VEC4:
            in.attributes[i].v4 = *(glm::vec4*)(buffer);
            continue;
        case AttributeType::VEC3:
            in.attributes[i].v3 = *(glm::vec3*)(buffer);
            continue;
        case AttributeType::VEC2:
            in.attributes[i].v2 = *(glm::vec2*)(buffer);
            continue;
        case AttributeType::FLOAT:
            in.attributes[i].v1 = *(float*)(buffer);
            continue;
        case AttributeType::EMPTY:
            continue;
        }
    }
}

uint32_t computeVertexID(VertexArray const& vao, uint32_t shaderInvocation) {
    if (!vao.indexBuffer)return shaderInvocation;

    if (vao.indexType == IndexType::UINT32) {
        uint32_t* ind = (uint32_t*)vao.indexBuffer;
        return ind[shaderInvocation];
    }
    if (vao.indexType == IndexType::UINT16) {
        uint16_t* ind = (uint16_t*)vao.indexBuffer;
        return ind[shaderInvocation];
    }
    if (vao.indexType == IndexType::UINT8) {
        uint8_t* ind = (uint8_t*)vao.indexBuffer;
        return ind[shaderInvocation];
    }

}

auto VertexFetch(GPUContext& ctx, uint32_t index)
{
    InVertex in;
    in.gl_VertexID = computeVertexID(ctx.vao, index);
    VertexAssembly(ctx, in);
    return in;

}

void PrimitiveAssembly(GPUContext& ctx, Triangle triangle, uint32_t index)
{
    for (int i = 0; i < 3; i++)
    {
        InVertex in = VertexFetch(ctx, index + i);
        ctx.prg.vertexShader(triangle[i], in, ctx.prg.uniforms);
    }
}

//! [drawImpl]
void drawImpl(GPUContext& ctx, uint32_t nofVertices) {
    /// \todo Tato funkce vykreslí trojúhelníky podle daného nastavení.<br>
    /// ctx obsahuje aktuální stav grafické karty.
    /// Parametr "nofVertices" obsahuje počet vrcholů, který by se měl vykreslit (3 pro jeden trojúhelník).<br>
    /// Bližší informace jsou uvedeny na hlavní stránce dokumentace.


    for (int i = 0; i < nofVertices; i += 3) {//smyčka přes vrcholy
        Triangle triangle;
        PrimitiveAssembly(ctx, triangle, i);


    }

}
//! [drawImpl]

/**
 * @brief This function reads color from texture.
 *
 * @param texture texture
 * @param uv uv coordinates
 *
 * @return color 4 floats
 */
glm::vec4 read_texture(Texture const& texture, glm::vec2 uv) {
    if (!texture.data)return glm::vec4(0.f);
    auto uv1 = glm::fract(uv);
    auto uv2 = uv1 * glm::vec2(texture.width - 1, texture.height - 1) + 0.5f;
    auto pix = glm::uvec2(uv2);
    //auto t   = glm::fract(uv2);
    glm::vec4 color = glm::vec4(0.f, 0.f, 0.f, 1.f);
    for (uint32_t c = 0; c < texture.channels; ++c)
        color[c] = texture.data[(pix.y * texture.width + pix.x) * texture.channels + c] / 255.f;
    return color;
}

/**
 * @brief This function clears framebuffer.
 *
 * @param ctx GPUContext
 * @param r red channel
 * @param g green channel
 * @param b blue channel
 * @param a alpha channel
 */
void clear(GPUContext& ctx, float r, float g, float b, float a) {
    auto& frame = ctx.frame;
    auto const nofPixels = frame.width * frame.height;
    for (size_t i = 0; i < nofPixels; ++i) {
        frame.depth[i] = 10e10f;
        frame.color[i * 4 + 0] = static_cast<uint8_t>(glm::min(r * 255.f, 255.f));
        frame.color[i * 4 + 1] = static_cast<uint8_t>(glm::min(g * 255.f, 255.f));
        frame.color[i * 4 + 2] = static_cast<uint8_t>(glm::min(b * 255.f, 255.f));
        frame.color[i * 4 + 3] = static_cast<uint8_t>(glm::min(a * 255.f, 255.f));
    }
}

