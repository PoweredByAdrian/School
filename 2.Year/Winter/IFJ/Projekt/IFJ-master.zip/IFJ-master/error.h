/**
 * -----------------------------------------------------------
 * Projekt: Implementace prekladace imperativniho jazyka {{ project.language }}
 * Varianta: {{ project.variant }}
 * Autori:	{{ project.authors }}
 * Datum: {{ datetime.now }}
 *
 *
 * Soubor: {{ filename }}
 * -----------------------------------------------------------
 */
#ifndef ERROR_H
#define ERROR_H


#define ERROR(x) fprintf(stderr, x)

#define SUCCESS 0 // No Error Found

// Errors
#define ERR_LEXICAL 1 // Lexical Error
#define ERR_SYNTAX 2 // Syntax Error
#define ERR_SEM_DEFINE 3 // Undefined func/var, defining an already defined func/var...
#define ERR_SEM_TYPE 4 // Type incompability in assigment
#define ERR_SEM_PARAM 5 // Wrong number of parameters or return values in functions
#define ERR_SEM_TYPE_EXPR 6 // Type incompability in expressions
#define ERR_SEM_OTHER 7 // Other semantic errors
#define ERR_NIL 8 // Attempt to call nil
#define ERR_SEM_DIVZ 9 // Division by zero
#define ERR_INTERNAL 99 // Internal Error

#endif
