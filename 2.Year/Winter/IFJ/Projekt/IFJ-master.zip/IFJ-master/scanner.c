/**
 * -----------------------------------------------------------
 * Projekt: Implementace prekladace imperativniho jazyka IFJ20
 * Varianta: II.
 * Autori:	Patrik Slovák		<xslova21@stud.fit.vutbr.cz>
 *			Ondřej Dohnal	<xdohna45@stud.fit.vutbr.cz>
 *			Dominik Milota		<xmilot05@stud.fit.vutbr.cz>
 *			Jozef Meľuch			<xmeluc01@stud.fit.vutbr.cz>
 * Datum: Listopad 2020
 *
 *
 * Soubor: scanner.c
 * -----------------------------------------------------------
 */

#include "scanner.h"
#include <ctype.h>

TTokenType id_or_kw(string *str){
    const char* s = strToConst(str);
    if(!strcmp(s, "do")) return DO;
    else if(!strcmp(s,"else"))return ELSE;
    else if(!strcmp(s, "end"))return END;
    else if(!strcmp(s, "function"))return FUNCTION;
    else if(!strcmp(s,"global"))return GLOBAL;
    else if(!strcmp(s,"if"))return IF;
    else if(!strcmp(s,"integer"))return INTEGER;
    else if(!strcmp(s,"local"))return LOCAL;
    else if(!strcmp(s,"nil"))return NIL;
    else if(!strcmp(s,"number"))return NUMBER;
    else if(!strcmp(s,"require"))return REQUIRE;
    else if(!strcmp(s,"return"))return RETURN;
    else if(!strcmp(s,"string"))return STRING;
    else if(!strcmp(s,"then"))return THEN;
    else if(!strcmp(s,"while"))return WHILE;
    else return ID;
}

static void process_integer(string *str, Token *token)
{
	char *endptr;

	strtoll(strToConst(str), &endptr, 10);
	if (*endptr)
	{
        ERROR("Internal error occured.");
		exit(ERR_INTERNAL);
	}

	token_set_type(token, INTEGER);
	token_set_value(token, strToConst(str));
    token_set_nonterm(token, false);
}

static void process_float(string *str, Token *token)
{
	char *endptr;

	strtod(strToConst(str), &endptr);
	if (*endptr)
	{
        ERROR("Internal error occured.");
		exit(ERR_INTERNAL);
	}

	token_set_type(token, NUMBER);
	token_set_value(token, strToConst(str));
    token_set_nonterm(token, false);
}

Token* getNextToken(){
    Token *token = token_new(EMPTY, "EMPTY", false);

    char symbol;
    short escape;
    char *endptr;
    string str;


    if(!strInit(&str)){
        ERROR("Internal error occured.");
        exit(ERR_INTERNAL);
    };    

    ScannerState state = STATE_START;

    while(true){
        symbol = getc(stdin);
        if(symbol == EOF){
            token_set_type(token, EOFI);
            token_set_value(token, "EOFI");
            token_set_nonterm(token, false);
            return token;
        }
        switch (state){
            case STATE_START:
                if(isspace(symbol) && symbol != '\n') state = STATE_START;
                else if(symbol == '\n') state = STATE_EOL;
                else if(symbol == '/') state = STATE_DIV_NUM;
                else if(symbol == '=') state = STATE_ASSIGN;
                else if(symbol == '(') state = STATE_LBRACKET;
                else if(symbol == ')') state = STATE_RBRACKET;
                else if(symbol == '-') state = STATE_MINUS;
                else if(symbol == '*') state = STATE_MUL;
                else if(symbol == '+') state = STATE_PLUS;
                else if(symbol == '.') state = STATE_DOT;
                else if(symbol == '~') state = STATE_TILDE;
                else if(symbol == '#') state = STATE_HASH;
                else if(symbol == '<') state = STATE_LT;
                else if(symbol == '>') state = STATE_GT;
                else if(symbol == '[') state = STATE_BLOCK_COMMENT_START;
                else if(symbol == ':') state = STATE_COLON;
                else if(symbol == ',') state = STATE_COMMA;
                else if(symbol == '"'){
                    state = STATE_STRING_START;
                    strClear(&str);
                    escape = 0;
                }
                else if(isalpha(symbol) || symbol == '_'){
                     state = STATE_KW_OR_ID;
                     strClear(&str);
                     strAddChar(&str, symbol);
                }
                else if(isdigit(symbol)){
                    state = STATE_NUMERIC;
                    strClear(&str);
                    strAddChar(&str, symbol);
                }
                else{
                    ERROR("Chyba v ramci lexikalni analyzy - neocekavany symbol");
                    exit(ERR_LEXICAL);
                }
                break;
            case STATE_DIV_NUM:
                if(symbol == '/') state = STATE_DIV_INT;
                else {
                    ungetc(symbol, stdin);
                    token_set_type(token, DIV_NUM);
                    token_set_value(token, "/");
                    token_set_nonterm(token, false);
                    return token;
                }
                break;
            case STATE_DIV_INT:
                ungetc(symbol, stdin);
                token_set_type(token, DIV_INT);
                token_set_value(token, "//");
                token_set_nonterm(token, false);
                return token;
                break;
            case STATE_ASSIGN:
                if(symbol == '=') state = STATE_EQ;
                else{
                    ungetc(symbol, stdin);
                    token_set_type(token, ASSIGN);
                    token_set_value(token, "=");
                    token_set_nonterm(token, false);
                    return token;
                }
                break;
            case STATE_EQ:
                ungetc(symbol, stdin);
                token_set_type(token, EQ);
                token_set_value(token, "==");
                token_set_nonterm(token, false);
                return token;
                break;
            case STATE_LBRACKET:
                ungetc(symbol, stdin);
                token_set_type(token, LBRACKET);
                token_set_value(token, "(");
                token_set_nonterm(token, false);
                return token;
                break;
            case STATE_RBRACKET:
                ungetc(symbol, stdin);
                token_set_type(token, RBRACKET);
                token_set_value(token, ")");
                token_set_nonterm(token, false);
                return token;
                break;
            case STATE_MINUS:
                if(symbol =='-') state = STATE_COMMENT;
                else{
                    ungetc(symbol, stdin);
                    token_set_type(token, MINUS);
                    token_set_value(token, "-");
                    token_set_nonterm(token, false);
                    return token;
                }
                break;
            case STATE_COMMENT:
                if(symbol == '\n') state = STATE_START;
                break;
            case STATE_COMMA:
                ungetc(symbol, stdin);
                token_set_type(token, COMMA);
                token_set_value(token, ",");
                token_set_nonterm(token, false);
                return token;
                break;
            case STATE_MUL:
                ungetc(symbol, stdin);
                token_set_type(token, MUL);
                token_set_value(token, "*");
                token_set_nonterm(token, false);
                return token;
                break;
            case STATE_EOL:
                ungetc(symbol, stdin);
                token_set_type(token, EOL);
                token_set_value(token, "\n");
                token_set_nonterm(token, false);
                return token;
                break;
            case STATE_PLUS:
                ungetc(symbol, stdin);
                token_set_type(token, PLUS);
                token_set_value(token, "+");
                token_set_nonterm(token, false);
                return token;
                break;
            case STATE_DOT:
                if(symbol == '.') state = STATE_DOUBLEDOT;
                else{
                    ERROR("Chyba v ramci lexikalni analyzy. Neocekavana .");
                    exit(ERR_LEXICAL);
                }
                break;
            case STATE_DOUBLEDOT:
                ungetc(symbol, stdin);
                token_set_type(token, DOUBLEDOT);
                token_set_value(token, "..");
                token_set_nonterm(token, false);
                return token;
                break;
            case STATE_TILDE:
                if(symbol == '=') state = STATE_NEQ;
                else{
                    ERROR("Chyba v ramci lexikalni analyzy. Neocekavana ~");
                    exit(ERR_LEXICAL);
                }
            case STATE_NEQ:
                ungetc(symbol, stdin);
                token_set_type(token, NEQ);
                token_set_value(token, "~=");
                token_set_nonterm(token, false);
                return token;
                break;
            case STATE_HASH:
                ungetc(symbol, stdin);
                token_set_type(token, HASH);
                token_set_value(token, "#");
                token_set_nonterm(token, false);
                return token;
                break;
            case STATE_LT:
                if(symbol == '=') state = STATE_LTEQ;
                else{
                    ungetc(symbol, stdin);
                    token_set_type(token, LT);
                    token_set_value(token, "<");
                    token_set_nonterm(token, false);
                    return token;
                }
                break;
            case STATE_LTEQ:
                ungetc(symbol, stdin);
                token_set_type(token, LTEQ);
                token_set_value(token, "<=");
                token_set_nonterm(token, false);
                return token;
                break;
            case STATE_GT:
                if(symbol == '=') state = STATE_GTEQ;
                else{
                    ungetc(symbol, stdin);
                    token_set_type(token, GT);
                    token_set_value(token, ">");
                    token_set_nonterm(token, false);
                    return token;
                }
                break;
            case STATE_GTEQ:
                ungetc(symbol, stdin);
                token_set_type(token, GTEQ);
                token_set_value(token, ">=");
                token_set_nonterm(token, false);
                return token;
                break;
            case STATE_KW_OR_ID:
                if(isalnum(symbol) || symbol == '_'){
                    strAddChar(&str, symbol);
                }
                else{
                    ungetc(symbol, stdin);
                    token_set_type(token, id_or_kw(&str));
                    token_set_value(token, strToConst(&str));
                    token_set_nonterm(token, false);
                    return token;
                }
                break;
            case STATE_BLOCK_COMMENT_START:
                if(symbol == '[') state = STATE_BLOCK_COMMENT;
                else{
                    ERROR("Chyba v ramci lexikalni analyzy. Neocekavana [");
                    exit(ERR_LEXICAL);
                }
                break;
            case STATE_BLOCK_COMMENT:
                if(symbol == ']') state = STATE_BLOCK_COMMENT_END;
                break;
            case STATE_BLOCK_COMMENT_END:
                if(symbol == ']') state = STATE_START;
                else state = STATE_BLOCK_COMMENT;
                break;
            case STATE_STRING_START:
                if(symbol == '"') state = STATE_STRING_END;
                else if(symbol == '\\') state = STATE_STRING_ESCAPE;
                else{
                    strAddChar(&str, symbol);
                    state = STATE_STRING_START;
                }
                break;
            case STATE_STRING_ESCAPE:
                if(symbol == 'n'){
                    state = STATE_STRING_START;
                    strAddChar(&str, '\n');
                }
                else if(symbol == 't'){
                    state = STATE_STRING_START;
                    strAddChar(&str, '\t');
                }
                else if(symbol == '"'){
                    state = STATE_STRING_START;
                    strAddChar(&str, '"');
                }
                else if(symbol == '\\'){
                    state = STATE_STRING_START;
                    strAddChar(&str, '\\');
                }
                else if(BETWEEN(symbol, '0', '2')){
                    ERROR("IAMHERE");
                    state = STATE_STRING_ESCAPE_1;
                    escape += 100*(symbol - '0');
                }
                else{
                    ERROR("Chyba v ramci lexikalni analyzy. Escape sekvence je chybna");
                    exit(ERR_LEXICAL);
                }
                break;
            case STATE_STRING_ESCAPE_1:
                if(BETWEEN(symbol, '0', '9')){
                    state = STATE_STRING_ESCAPE_2;
                    escape += 10*(symbol - '0');
                }
                else{
                    ERROR("Chyba v ramci lexikalni analyzy. Escape sekvence je chybna");
                    exit(ERR_LEXICAL);
                }
                break;
            case STATE_STRING_ESCAPE_2:
                if(BETWEEN(symbol, '0', '9')){
                    state = STATE_STRING_START;
                    escape += (symbol - '0');
                    if(escape > 255){
                        ERROR("Chyba v ramci lexikalni analyzy. Escape sekvence musi byt v rozsahu 000-255");
                        exit(ERR_LEXICAL);    
                    }
                    strAddChar(&str, escape);
                }
                else{
                    ERROR("Chyba v ramci lexikalni analyzy. Escape sekvence je chybna");
                    exit(ERR_LEXICAL);
                }
                break;
            case STATE_STRING_END:
                ungetc(symbol, stdin);
                token_set_type(token, STRING);
                token_set_value(token, strToConst(&str));
                token_set_nonterm(token, false);
                return token;
            case STATE_COLON:
                ungetc(symbol, stdin);
                token_set_type(token, COLON);
                token_set_value(token, ":");
                token_set_nonterm(token, false);
                return token;
            case STATE_NUMERIC:
                if(isdigit(symbol)) strAddChar(&str, symbol);
                else if(symbol == '.'){
                    strAddChar(&str, symbol);
                    state = STATE_DECIMAL;
                }
                else if(symbol == 'e' || symbol == 'E'){
                    strAddChar(&str, symbol);
                    state = STATE_EXP;
                }
                else {
                    ungetc(symbol, stdin);
                    token_set_type(token, INTEGER);
                    token_set_value(token, strToConst(&str));
                    token_set_nonterm(token, false);
                    return token;
                }
                break;
            case STATE_DECIMAL:
                if(isdigit(symbol)){
                    strAddChar(&str, symbol);
                    state = STATE_DECIMAL_VALUE;
                }
                else{
                    ERROR("Chyba v ramci lexikalni analyzy. Neocekavany symbol v desetinnem cisle");
                    exit(ERR_LEXICAL);
                }
                break;
            case STATE_DECIMAL_VALUE:
                if(isdigit(symbol)) strAddChar(&str, symbol);
                else if(symbol == 'e' || symbol == 'E'){
                    strAddChar(&str, symbol);
                    state = STATE_EXP;
                }
                else{
                    ungetc(symbol, stdin);
                    token_set_type(token, NUMBER);
                    token_set_value(token, strToConst(&str));
                    token_set_nonterm(token, false);
                    return token;
                }
                break;
            case STATE_EXP:
                if(isdigit(symbol)){
                    strAddChar(&str, symbol);
                    state = STATE_EXP_VALUE;
                }
                else if(symbol == '+' || symbol == '-'){
                    strAddChar(&str, symbol);
                    state = STATE_EXP_SIGN;
                }
                else{
                    ERROR("Chyba v ramci lexikalni analyzy. Neocekavany znak v exponentu.");
                    exit(ERR_LEXICAL);
                }
                break;
            case STATE_EXP_VALUE:
                if(isdigit(symbol)) strAddChar(&str, symbol);
                else{
                    ungetc(symbol, stdin);
                    token_set_type(token, NUMBER);
                    token_set_value(token, strToConst(&str));
                    token_set_nonterm(token, false);
                    return token;
                }
                break;
            case STATE_EXP_SIGN:
                if(isdigit(symbol)){
                    state = STATE_EXP_VALUE;
                    strAddChar(&str, symbol);
                }
                else{
                    ERROR("Chyba v ramci lexikalni analyzy. Neocekavany znak v exponentu.");
                    exit(ERR_LEXICAL);
                }
                break;
        }
    }
}


int main(){
    Token *token;
    printf("Scanner result:\n");
    do{
        token = getNextToken();
        //printf("Type: %d\tValue: %s\n",token_get_type(token), token_get_value(token));
        printf("%s ",token_get_value(token));
    }
    while(token_get_type(token)!=EOFI);
}
/*
int scan(Queue*  queue){
    Token * token = token_new(EMPTY, "", false);
    while(token_get_type(token) != EOFI){
        token = getNextToken();
        if(!token){
            return ERR_INTERNAL;
        }
        if(token_get_type(token) != COMMENT)
        if(!queue_push(queue, token)){
            return ERR_INTERNAL;
        }
    }
    return SUCCESS;
}
*/