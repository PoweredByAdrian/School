/**
 * -----------------------------------------------------------
 * Projekt: Implementace prekladace imperativniho jazyka {{ project.language }}
 * Varianta: {{ project.variant }}
 * Autori:	{{ project.authors }}
 * Datum: {{ datetime.now }}
 *
 *
 * Soubor: {{ filename }}
 * -----------------------------------------------------------
 */

#ifndef IFJ20_STR_H
#define IFJ20_STR_H

#include <stdbool.h>

typedef struct {
  char* str; // The actual string data
  int length; // Length of the string
  int size; // Allocated Memory Size | How many chars allocated
} string;

bool strInit(string* str);
void strFree(string* str);
void strClear(string* str);
bool strAddChar(string* str, char c);
bool strAddConst(string* str, char* str_const);
bool strCopy(string* src, string* dest);
int strCmp(string* str1, string* str2);
int strCmpConst(string* str, char* str_const);
char* strToConst(string* str);

#endif