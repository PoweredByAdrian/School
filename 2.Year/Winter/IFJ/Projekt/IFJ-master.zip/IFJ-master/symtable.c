/**
 * -----------------------------------------------------------
 * Projekt: Implementace prekladace imperativniho jazyka {{ project.language }}
 * Varianta: {{ project.variant }}
 * Autori:	{{ project.authors }}
 * Datum: {{ datetime.now }}
 *
 *
 * Soubor: {{ filename }}
 * -----------------------------------------------------------
 */
#include "symtable.h"
#include "tokenstack.h"
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

int getHash(char* key){
    int hash = 1;
    int keylen = strlen(key);
    for ( int i=0; i<keylen; i++ )
        hash += key[i];
    return ( hash % MAX_SIZE );
}

void STInit(STable* table){
    if (table == NULL) return;
    for (int i = 0; i < MAX_SIZE; i++){
        (*table)[i] = NULL;
    }
}

bool STInsert(STable* table, char* key, STData* content){
    if (table == NULL || key == NULL) {
      return false;
    }

    if (STSearch(table, key)) {
      return false;
    }

    STItem *newItem = (STItem *) malloc(sizeof(STItem));
    if (newItem == NULL)
    {
        return false;
    }
    newItem->key = key;
    newItem->next = (*table)[getHash(key)];
    if (content != NULL) {
      newItem->idata = *content;
    }
    (*table)[getHash(key)] = newItem;
    return true;
}

void STFree(STable* table){
    if (table == NULL) {
      return;
    }
    STItem *item;
    STItem *next;
    for (int i = 0; i < MAX_SIZE; i++)
    {
        item = (*table)[i];
        next = NULL;
        while (item != NULL)
        {
            next = item->next;
            strFree(&item->idata.value);
            strFree(&item->idata.params);
            strFree(&item->idata.retTypes);
            free(item->key);
            free(item);
            item = next;
        }
        (*table)[i] = NULL;
    }
}

STData* STSearch(STable* table, char* key){
    //printf("%s\n", key);
    if (table == NULL || key == NULL) {
      return NULL;
    }
    STItem *item = (*table)[getHash(key)];
    while(item != NULL)
    {
        if (strcmp(key, item->key) == 0)
        {
            return &(item->idata);
        }
        item = item->next;
    }
    return NULL;
}

bool STInitData(STData* data) {
  if (data == NULL) {
    return false;
  }
  data->type = TYPE_UNDEFINED;
  data->defined = false;
  data->function = false;
  data->ret = false;
  if (strInit(&(data->value)) != true) {
    return false;
  }
  if (strInit(&(data->params)) != true) {
    return false;
  }
  if (strInit(&(data->retTypes)) != true) {
    return false;
  }
  return true;
}

void STFreeData(STData* data) {
  if (data == NULL) {
    return;
  }
  if (&(data->value) != NULL) {
    strFree(&(data->value));
  }
  if (&(data->params) != NULL) {
    strFree(&(data->params));
  }
  if (&(data->retTypes) != NULL) {
    strFree(&(data->retTypes));
  }
}

void LSTInit(LSTStack* stack){
    if (stack == NULL) {
      return;
    }
    *stack = NULL;
}

bool LSTPush(LSTStack* stack){
    if (stack == NULL) {
      return false;
    }
    LSTable* newitem = malloc(sizeof(LSTable));
    if (newitem == NULL) {
      return false;
    }
    newitem->next = *stack;
    STInit(&(newitem->table));
    *stack = newitem;
    return true;
}

void LSTPop(LSTStack* stack){
    if (stack == NULL) {
      return;
    }
    LSTable* next = (*stack)->next;
    STFree(&(*stack)->table);
    free(*stack);
    *stack = next;
}

void LSTDestroy(LSTStack* stack){
    while(*stack != NULL)
    {
        LSTPop(stack);
    }
}

STable* LSTFirst(LSTStack stack){
    if (stack == NULL) {
      return NULL;
    }
    return &stack->table;
}

STData* LSTSearch(LSTStack stack, char* key) {
  STData* data = NULL;
  for (LSTable* stk = stack; stk != NULL; stk = stk->next) {
    data = STSearch(&(stk->table), key);
    if (data != NULL) {
      return data;
    }
  }
  return NULL;
}
