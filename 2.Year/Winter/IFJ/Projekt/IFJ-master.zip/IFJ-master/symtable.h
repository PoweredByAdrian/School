/**
 * -----------------------------------------------------------
 * Projekt: Implementace prekladace imperativniho jazyka {{ project.language }}
 * Varianta: {{ project.variant }}
 * Autori:	{{ project.authors }}
 * Datum: {{ datetime.now }}
 *
 *
 * Soubor: {{ filename }}
 * -----------------------------------------------------------
 */
#ifndef _SYMTABLE_H_
#define _SYMTABLE_H_

#include "str.h"
#include "token.h"
#include <stdbool.h>

#define TYPE_INT 1
#define TYPE_FLOAT 2
#define TYPE_STRING 3
#define TYPE_UNDEFINED 4

#define MAX_SIZE 101 // The size of the ST, must be a prime number

typedef struct tSTData {
  int type; // variable type or return type of func
  bool function; // true: function, false: var
  bool ret;
  bool defined;
  char* name;
  string value;
  string params; //func parameters, each char stands for one variable ,i - int, f - float, s - string
  string retTypes; //func return types
} STData;

typedef struct tSTItem {
  char* key;
  STData idata;
  struct tSTItem* next;
} STItem;

typedef STItem* STable[MAX_SIZE];

typedef struct tLSTable {
    STable table;
    struct tLSTable* next;
} LSTable;

typedef LSTable* LSTStack;

int getHash(char* key);
void STInit(STable* table);
bool STInsert(STable* table, char* key, STData* content);
void STFree(STable* table);
STData* STSearch(STable* table, char* key);
bool STInitData(STData* data);
void STFreeData(STData* data);
void LSTInit(LSTStack* stack);
bool LSTPush(LSTStack* stack);
void LSTPop(LSTStack* stack);
void LSTDestroy(LSTStack* stack);
STable* LSTFirst(LSTStack stack);
STData* LSTSearch(LSTStack stack, char* key);
//bool checkMissing(STable* missing,STable* global);
#endif
