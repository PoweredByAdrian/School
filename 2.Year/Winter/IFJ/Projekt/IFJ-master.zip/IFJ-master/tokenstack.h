/**
 * -----------------------------------------------------------
 * Projekt: Implementace prekladace imperativniho jazyka {{ project.language }}
 * Varianta: {{ project.variant }}
 * Autori:	{{ project.authors }}
 * Datum: {{ datetime.now }}
 *
 *
 * Soubor: {{ filename }}
 * -----------------------------------------------------------
 */

#ifndef TOKENSTACK_H
#define TOKENSTACK_H

#include <stdbool.h>
#include "type.h"
#include "token.h"

typedef struct tokenStackItem{
  Token* token;
  struct tokenStackItem* next;
} tStackItem;

typedef struct tokenStack{
  tStackItem* top;
} tStack;

// Functions
void tStackInit(tStack* stack);
bool tStackPush(tStack* stack, Token* token);
Token* tStackPop(tStack* stack);
void tStackDestroy(tStack* stack);

#endif
