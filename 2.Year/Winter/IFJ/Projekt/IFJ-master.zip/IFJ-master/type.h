/**
 * -----------------------------------------------------------
 * Projekt: Implementace prekladace imperativniho jazyka {{ project.language }}
 * Varianta: {{ project.variant }}
 * Autori:	{{ project.authors }}
 * Datum: {{ datetime.now }}
 *
 *
 * Soubor: {{ filename }}
 * -----------------------------------------------------------
 */

#ifndef IFJ20_TYPE_H
#define IFJ20_TYPE_H
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "str.h"
typedef enum TokenType{
    EMPTY,
    EOL,
    DO,
    ELSE,
    END,
    FUNCTION,
    GLOBAL,
    IF,
    INTEGER,
    LOCAL,
    NIL,
    NUMBER,
    REQUIRE,
    RETURN,
    STRING,
    THEN,
    WHILE,
    ID,
    TYPE,
    COLON,
    LT,
    GT,
    LTEQ,
    GTEQ,
    EQ,
    NEQ,
    DOUBLEDOT,
    ASSIGN,
    PLUS,
    MINUS,
    MUL,
    DIV_NUM,
    DIV_INT,
    COMMENT,
    HASH,
    LBRACKET,
    RBRACKET,
    COMMA,
    EOFI
} TTokenType;

#endif //IFJ_TYPE_H
